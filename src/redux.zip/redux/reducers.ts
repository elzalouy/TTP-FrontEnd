import { combineReducers } from "redux";
import orders from "./order/reducer";

export default combineReducers({
  orders,
});

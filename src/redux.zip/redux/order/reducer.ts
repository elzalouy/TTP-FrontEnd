import { Action } from '@reduxjs/toolkit';
import { OrderModel } from "../../models/order.model";
import {
  CREATE_ORDER,
  RETRIEVE_ORDERS,
  UPDATE_ORDER,
  DELETE_ORDER,
  DELETE_ALL_ORDERS,
} from "./types";

export interface ActionWithPayload<T> extends Action {
  payload?: T
}

export interface IOrderState {
  list: OrderModel[]
  listCount: number
  listLoading?: boolean
  listError?: any
  saveLoading?: boolean
  saveSuccess?: any
  saveError?: any
  deleteLoading?: boolean
  deleteSuccess?: any
  deleteError?: any
}
const initialState: IOrderState = {
  list: [],
  listCount: 0,
  listLoading: false,
  listError: undefined,
  saveLoading: false,
  saveSuccess: undefined,
  saveError: undefined,
  deleteLoading: false,
  deleteSuccess: undefined,
  deleteError: undefined,
}

function orderReducer(orderState = initialState, action: ActionWithPayload<IOrderState>) {
  const { type, payload } = action;

  switch (type) {
    case CREATE_ORDER:
      return [...orderState.list, payload];

    case RETRIEVE_ORDERS:
      return payload;

    case UPDATE_ORDER:
      return payload;

    case DELETE_ORDER:
      return payload;

    case DELETE_ALL_ORDERS:
      return [];

    default:
      return orderState;
  }
};

export default orderReducer;
import {
  CREATE_ORDER,
  RETRIEVE_ORDERS,
  UPDATE_ORDER,
  DELETE_ORDER
} from "./types";

import OrderDataService from "../../services/order.service";

export const createOrder = (title:string, description:string) => async (dispatch:any) => {
  try {
    const res = await OrderDataService.create({ title, description });

    dispatch({
      type: CREATE_ORDER,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const retrieveOrders = () => async (dispatch:any) => {
  try {
    const res = await OrderDataService.getAll();
    dispatch({
      type: RETRIEVE_ORDERS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const updateOrder = (id:string, data:any) => async (dispatch:any) => {
  try {
    const res = await OrderDataService.update(id, data);

    dispatch({
      type: UPDATE_ORDER,
      payload: data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const deleteOrder = (id:string) => async (dispatch:any) => {
  try {
    await OrderDataService.delete(id);

    dispatch({
      type: DELETE_ORDER,
      payload: { id },
    });
  } catch (err) {
    console.log(err);
  }
};
